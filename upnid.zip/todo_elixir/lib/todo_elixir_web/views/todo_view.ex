defmodule TodoElixirWeb.TodoView do
  use TodoElixirWeb, :view
end
