defmodule TodoElixirWeb.LayoutView do
  use TodoElixirWeb, :view
end
