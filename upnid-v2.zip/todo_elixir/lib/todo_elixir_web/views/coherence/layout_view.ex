defmodule TodoElixirWeb.Coherence.LayoutView do
  use TodoElixirWeb.Coherence, :view
end
