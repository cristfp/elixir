defmodule TodoElixirWeb.Coherence.EmailView do
  use TodoElixirWeb.Coherence, :view
end
