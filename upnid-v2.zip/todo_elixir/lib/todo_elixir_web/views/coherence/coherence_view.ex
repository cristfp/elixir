defmodule Coherence.CoherenceView do
  use TodoElixirWeb.Coherence, :view
end
