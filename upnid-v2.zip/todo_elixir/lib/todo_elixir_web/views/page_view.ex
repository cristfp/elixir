defmodule TodoElixirWeb.PageView do
  use TodoElixirWeb, :view
end
