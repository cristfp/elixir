defmodule TodoElixirWeb.UserView do
  use TodoElixirWeb, :view
end
