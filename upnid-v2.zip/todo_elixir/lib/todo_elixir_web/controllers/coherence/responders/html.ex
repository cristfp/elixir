defmodule Coherence.Responders.Html do
  use Responders.Html
end
