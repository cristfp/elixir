defmodule Coherence.Responders.Json do
  use Responders.Json
end
