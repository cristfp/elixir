defmodule TodoElixirWeb.Router do
  use TodoElixirWeb, :router
  use Coherence.Router  

  pipeline :browser do
    plug :accepts, ["html"]
    plug :fetch_session
    plug :fetch_flash
    plug :protect_from_forgery
    plug :put_secure_browser_headers
    plug Coherence.Authentication.Session
  end

  pipeline :protected do
    plug :accepts, ["html"]
    plug :fetch_session
    plug :fetch_flash
    plug :protect_from_forgery
    plug :put_secure_browser_headers
    plug Coherence.Authentication.Session, protected: true  # Add this
  end

  pipeline :api do
    plug :accepts, ["json"]
  end

  scope "/" do
    pipe_through :browser
    coherence_routes
    coherence_routes :protected
  end

  scope "/", TodoElixirWeb do
    pipe_through :browser # Use the default browser stack
    get "/", PageController, :index
    resources "/todos", TodoController
    resources "/users", UserController
    resources "/pages", PageController
  end

  scope "/", CoherenceExampleWeb do
    pipe_through :browser
    get "/", PageController, :index
    # Add public routes below
    #resources "/registrations", RegistrationController
  end

  scope "/", CoherenceExampleWeb do
    pipe_through :protected
    # Add protected routes below
  end
end

  # Other scopes may use custom stacks.
  # scope "/api", TodoElixirWeb do
  #   pipe_through :api
  # end

