defmodule Coherence.CoherenceView do
  use <%= web_module %>, :view
end
