defmodule <%= web_base %>.Coherence.EmailView do
  use <%= web_module %>, :view
end
