defmodule <%= web_base %>.Coherence.LayoutView do
  use <%= web_module %>, :view
end
