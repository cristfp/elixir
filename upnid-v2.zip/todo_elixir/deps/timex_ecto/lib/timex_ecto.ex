defmodule Timex.Ecto do
  @moduledoc File.read!("README.md")
end
